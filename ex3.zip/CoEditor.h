// CoEditor.h
#ifndef COEDITOR_H
#define COEDITOR_H

#include "BoundedBuffer.h"

void coEditorFunction(BoundedBuffer& inputBuffer, BoundedBuffer& outputBuffer);

#endif // COEDITOR_H