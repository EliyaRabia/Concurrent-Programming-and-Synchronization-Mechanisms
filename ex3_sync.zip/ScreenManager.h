#ifndef SCREENMANAGER_H
#define SCREENMANAGER_H

#include "BoundedBuffer.h"

void screenManagerFunction(BoundedBuffer& buffer);

#endif
